
public class PublicAccessSpecifier {
	public class pubaccessspecifiers {

		public void display() 
	    { 
	        System.out.println("This is Public Access Specifiers"); 
	    } 
	}

	//create another package
	public static class accessSpecifiers4 {

		public static void main(String[] args) {
			
			PublicAccessSpecifier.pubaccessspecifiers obj = new PublicAccessSpecifier().new pubaccessspecifiers(); 
	        obj.display();  
			
		}
	}
}


