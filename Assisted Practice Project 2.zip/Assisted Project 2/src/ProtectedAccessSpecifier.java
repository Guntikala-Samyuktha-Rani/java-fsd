class ProtectedAccessSpecifier {
	    // 3. using protected access specifiers
	    public static class ProAccessSpecifiers {
	        protected void display() {
	            System.out.println("This is protected access specifier");
	        }
	    }

	    // create another class
	    public static class ProtectedAccessSpecifierNested extends ProAccessSpecifiers {
	        public static void main(String[] args) {
	            ProtectedAccessSpecifierNested obj = new ProtectedAccessSpecifierNested();
	            obj.display();
	        }
	    }
	}

