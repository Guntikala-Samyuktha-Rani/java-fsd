public class SingleInheritence {
    static class A {
        public void methodA() {
            System.out.println("Base class method");
        }
    }

    static class B extends A {
        public void methodB() {
            System.out.println("Child class method");
        }
    }

    public static void main(String[] args) {
        B obj = new B();
        obj.methodA(); // calling super class method
        obj.methodB(); // calling local method
    }
}



