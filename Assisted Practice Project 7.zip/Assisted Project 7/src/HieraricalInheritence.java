public class HieraricalInheritence {
	 class HierarchicalInheritance {
		 // Parent Class
	    static class Animal {
	        protected String name;

	        public Animal(String name) {
	            this.name = name;
	        }

	        public void eat() {
	            System.out.println(name + " is eating.");
	        }

	        public void sleep() {
	            System.out.println(name + " is sleeping.");
	        }
	    }
         // Child Class 1
	    static class Dog extends Animal {
	        public Dog(String name) {
	            super(name);
	        }

	        public void bark() {
	            System.out.println(name + " is barking.");
	        }
	    }
         // Child Class 2
	    static class Cat extends Animal {
	        public Cat(String name) {
	            super(name);
	        }

	        public void meow() {
	            System.out.println(name + " is meowing.");
	        }
	    }
         // Child Class 3
	    static class Cow extends Animal {
	        public Cow(String name) {
	            super(name);
	        }

	        public void moo() {
	            System.out.println(name + " is mooing.");
	        }
	    }

	    public static void main(String[] args) {
	        Dog dog = new Dog("Buddy");
	        dog.eat();
	        dog.sleep();
	        dog.bark();

	        Cat cat = new Cat("Whiskers");
	        cat.eat();
	        cat.sleep();
	        cat.meow();

	        Cow cow = new Cow("Bessie");
	        cow.eat();
	        cow.sleep();
	        cow.moo();
	    }
	}
}	