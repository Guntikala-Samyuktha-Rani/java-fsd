public class MultiLevelInheritence {
    static class X {
        public void methodX() {
            System.out.println("Class X method");
        }
    }

    static class Y extends X {
        public void methodY() {
            System.out.println("Class Y method");
        }
    }

    static class Z extends Y {
        public void methodZ() {
            System.out.println("Class Z method");
        }
    }

    public static void main(String[] args) {
        Z obj = new Z();
        obj.methodX(); // calling grandparent class method
        obj.methodY(); // calling parent class method
        obj.methodZ(); // calling local method
    }
}


