
public class PrivateAccessSpecifier {
	class PriAccessSpecifier {
	     void display() {
	        System.out.println("You are using private access specifier");
	    }

	    public static void main(String[] args) {
	        // private
	        System.out.println("Private Access Specifier");
	        PrivateAccessSpecifier.PriAccessSpecifier obj = new PrivateAccessSpecifier().new PriAccessSpecifier();
	        // Trying to access private method of another class
	       // obj.display(); // This line will cause a compile-time error
	        obj.display();
	    }
}
}
