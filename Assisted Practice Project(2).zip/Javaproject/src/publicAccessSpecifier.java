public class publicAccessSpecifier {

	public class pubaccessspecifiers {

		public void display() 
	    { 
	        System.out.println("This is Public Access Specifiers"); 
	    } 
	}

	//create another package
	public static class accessSpecifiers4 {

		public static void main(String[] args) {
			
			publicAccessSpecifier.pubaccessspecifiers obj = new publicAccessSpecifier().new pubaccessspecifiers(); 
	        obj.display();  
			
		}
	}
}


