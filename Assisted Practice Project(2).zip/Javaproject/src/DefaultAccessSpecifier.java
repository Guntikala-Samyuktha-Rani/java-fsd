

public class DefaultAccessSpecifier {
	//1. class having default access modifier	
		    class DefAccessSpecifier {
		        void display() {
		            System.out.println("You are using default access specifier");
		        }
		    }

		    public static void main(String[] args) {
		        // default
		        System.out.println("Default Access Specifier");
		        DefaultAccessSpecifier.DefAccessSpecifier obj = new DefaultAccessSpecifier().new DefAccessSpecifier();
		        obj.display();
		    }
		}


	
