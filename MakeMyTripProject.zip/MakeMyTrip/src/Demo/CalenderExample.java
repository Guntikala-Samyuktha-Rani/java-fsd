package Demo;

import org.openqa.selenium.By;


import org.openqa.selenium.chrome.ChromeDriver;


public class CalenderExample {
    public static void main(String[] args) throws InterruptedException {
        

       
        ChromeDriver driver = new ChromeDriver();

        
        driver.manage().window().maximize();

        
        driver.get("https://www.makemytrip.com/");
        
        driver.findElement(By.xpath("#root > div > div.minContainer > div > div > div.fsw > div.fsw_inner.returnPersuasion > div:nth-child(4) > label > span")).click();
       Thread.sleep(3000);
       
     driver.findElement( By.xpath("#root > div > div.minContainer > div > div > div.fsw.widgetOpen > div.fsw_inner.returnPersuasion > div.fsw_inputBox.dates.inactiveWidget.activeWidget > div.datePickerContainer > div > div > div > div.DayPicker > div > div.DayPicker-Months > div:nth-child(2) > div.DayPicker-Body > div:nth-child(2) > div:nth-child(4) > div")).click();
       Thread.sleep(3000);
       
    }
    
    
}

