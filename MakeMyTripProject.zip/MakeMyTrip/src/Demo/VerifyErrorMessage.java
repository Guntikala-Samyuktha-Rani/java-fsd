package Demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyErrorMessage {

	
		// TODO Auto-generated method stub
public static void main(String[] args) {
			
			ChromeDriver driver = new ChromeDriver();
			
			driver.get("https://www.makemytrip.com/");
			
			WebElement LoginocreateAccount = driver.findElement(By.linkText("Login or createAccount"));
			
			driver.findElement(By.id("email")).sendKeys("batmans554466@gmail.com");
			
			driver.findElement(By.id("pass")).sendKeys("password@123");
			
			driver.findElement(By.name("login")).click();
			
			String expectedErrMsg = "Please enter valid Email Id or Mobile Number.";
			
			String actualErrMsg = driver.findElement(By.xpath("//p[contains(@class,'validity font12 redText appendTop5 makeFlex')]")).getText();
			
			if(expectedErrMsg.equals(actualErrMsg)) {
				System.out.println("Test Case Passed");
				
			}
			else {
				System.out.println("Test Case Failed");
			}
			driver.quit();
			
		}

	}
	


