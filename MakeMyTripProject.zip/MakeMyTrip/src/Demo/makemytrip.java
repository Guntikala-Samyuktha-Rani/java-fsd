package Demo;

import org.openqa.selenium.By;
	
	import org.openqa.selenium.chrome.ChromeDriver;
	

	public class makemytrip {
		public static void main(String[] args) throws InterruptedException{
		    // 1) Open the browser
				ChromeDriver driver = new ChromeDriver();
				
				// 2) Maximize it
				driver.manage().window().maximize();
				
				// 3) Navigate to application
				driver.get("https://www.makemytrip.com/");
				
				
				driver.findElement(By.linkText("Trains")).click();
				
				// 5) Check last check box
				driver.findElement(By.xpath("//*[@id=\\\"root\\\"]/div/div[2]/div/div/div/div[1]/span[1]\"")).click();
				
				
				driver.findElement(By.id("travelDate")).click();
				
				
				driver.findElement(By.className("//*[@id=\"root\"]/div/div[2]/div/div/div/div[2]/div/div[4]/label")).click();
		
						

	}
		}

