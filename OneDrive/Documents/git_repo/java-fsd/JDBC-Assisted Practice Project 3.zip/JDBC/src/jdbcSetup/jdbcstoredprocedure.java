package jdbcSetup;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbcstoredprocedure {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String dburl = "jdbc:mysql://localhost:3306/ecommerce"; // Connection String
		String username = "root";
		String password = "Samyuktha@431";
		String query = "Call SelectAlleproduct();";
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(dburl, username, password); //Connecting to DB
		Statement stmt = con.createStatement(); //Execute the query
		ResultSet rs = stmt.executeQuery(query); // Save the result after executing the query
		
		while (rs.next()) {
			System.out.print("ID: " + rs.getString("id") + "\t");
			System.out.print("Name: " + rs.getString("name") + "\t");
			System.out.print("Price: " + rs.getString("price") + "\t");
			System.out.print("Date_Added: " + rs.getString("date_added") + "\t");
		}
	}	
	}	
	
	

	


