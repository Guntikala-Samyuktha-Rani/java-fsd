package AmazonWebPage;

import org.openqa.selenium.chrome.ChromeDriver;

public class NavigateToAmazonWebPage {

    public static void main(String[] args) {
        // Create a ChromeDriver instance
        ChromeDriver driver = new ChromeDriver();

        // Navigate to Amazon web page
        driver.get("https://www.amazon.in");

        // Close the browser and end the WebDriver session
        driver.quit();
    }
}
