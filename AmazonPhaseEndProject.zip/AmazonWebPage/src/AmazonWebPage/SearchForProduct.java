package AmazonWebPage;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SearchForProduct {

   

	public static void main(String[] args) throws InterruptedException {

        // Create a new instance of ChromeDriver
        ChromeDriver driver = new ChromeDriver();

        // Navigate to Amazon homepage
        driver.get("https://www.amazon.in/");
        WebElement mobiles = driver.findElement(By.linkText("Mobiles"));
        Actions actions = new Actions(driver);
		actions.moveToElement(mobiles).build().perform();
		Thread.sleep(3000);
		driver.findElement(By.linkText("Mobiles")).click();
		driver.findElement(By.linkText("Mobiles & Accessories")).click();
		driver.findElement(By.linkText("Apple")).click();
        

        WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
        searchBox.sendKeys("Iphone 13");

        driver.findElement(By.xpath("//input[contains(@id,'nav-search-submit-button')]")).click();

        driver.findElement(By.linkText("Apple iPhone 13 Mini (512GB) - Starlight")).click();

       
        Set<String> S = driver.getWindowHandles();
        ArrayList ar = new ArrayList(S);
        ar.get(0);
        System.out.println(ar.get(0));
        System.out.println(ar.get(1));
        driver.switchTo().window((String)ar.get(1));
        
        driver.findElement(By.xpath("//input[contains(@id,'buy-now-button')]")).click();
    }
}

	
	

