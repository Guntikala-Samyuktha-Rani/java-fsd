
public class Constructor {
	public class Puppy {
		   public Puppy() {
		   }

		   public Puppy(String name) {
		      // This constructor has one parameter, name.
		   }}

}
