
public class Class { 
public class dog 
{
   String breed;
   int age;
   String color;

   void barking() {
   }
   void hungry() {
   }

   void sleeping() {
   }}}


